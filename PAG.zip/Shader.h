#pragma once
class Shader
{
public:
	Shader();
	~Shader();
};

