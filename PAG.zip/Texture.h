#pragma once
class Texture
{
public:
	Texture();
	~Texture();
};

